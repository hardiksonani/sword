<?php include('header.php');?> 
	<section class="home-slider">
    	<div class="tp-banner-container">
      		<div class="tp-banner-fix">
        		<ul>		
          			<li data-transition="fade" data-slotamount="7" style="background:#999900">
		  			<img src="images/slide-bg-1.jpg" data-bgposition="center top" alt="" />            
					<!-- Layer -->
					<div class="tp-caption sft tp-resizeme font-extra-bold" 
						  data-x="right" data-hoffset="0"
						  data-y="center" data-voffset="0" 
						  data-speed="700" 
						  data-start="700" 
						  data-easing="easeOutBack"
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1" 
						  data-endspeed="300" 
						  data-captionhidden="on"> <img src="images/operator-1.png" alt="" > </div>
					
					<!-- Layer -->
					<div class="tp-caption sfb tp-resizeme font-bold" 
						  data-x="left" data-hoffset="120"
						  data-y="center" data-voffset="-100"
						  data-speed="500" 
						  data-start="700" 
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-easing="Back.easeOut" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1"
						  data-endspeed="300" 
						  data-captionhidden="on"
						  style="color: #fff; font-size: 40px; font-weight: normal; letter-spacing:0px; line-height:55px;">
						  MOBILE AND DTH RECHARGE <br> Fastest and Reliable Service<br />
						  </div> 
						  <!-- Layer -->
					<div class="tp-caption sfb tp-resizeme font-bold" 
						  data-x="left" data-hoffset="120"
						  data-y="center" data-voffset="50"
						  data-speed="500" 
						  data-start="700" 
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-easing="Back.easeOut" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1"
						  data-endspeed="300" 
						  data-captionhidden="on"
						  style="color: #fff; font-size: 18px; font-weight: normal; letter-spacing:0px; line-height:24px;">
						  With the user base for telecom subscribers growing considerably<br /> online mobile recharge is becoming a popular concept day-by-day.<br /> Owing to busy working schedules and lack of time<br /> online recharging has proven to be a boon for the mobile/dth users.</div> 
					</li>
					
					<li data-transition="fade" data-slotamount="7"> 
					<img src="images/slide-bg-2.jpg" data-bgposition="center top" alt="" /> 
					<div class="tp-caption sft tp-resizeme font-extra-bold" 
						  data-x="left" data-hoffset="100"
						  data-y="center" data-voffset="0" 
						  data-speed="700" 
						  data-start="700" 
						  data-easing="easeOutBack"
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1" 
						  data-endspeed="300" 
						  data-captionhidden="on" 
						  > <img src="images/bus-1.png" alt="" > </div>
					<div class="tp-caption sfb tp-resizeme font-bold" 
						  data-x="right" data-hoffset="-50"
						  data-y="center" data-voffset="-100"
						  data-speed="500" 
						  data-start="700" 
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-easing="Back.easeOut" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1"
						  data-endspeed="300" 
						  data-captionhidden="on"
						  style="color: #fff; font-size: 40px; font-weight: normal; letter-spacing:0px; line-height:55px;">
						  BUS TICKET BOOKING <br> Fastest and Reliable Service<br />
						  </div> 
					<!-- Layer -->
					<div class="tp-caption sfb tp-resizeme font-crimson" 
						  data-x="right" data-hoffset="-440"
						  data-y="center" data-voffset="0"
						  data-speed="500" 
						  data-start="1300" 
						  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;" 
						  data-easing="Back.easeOut" 
						  data-splitin="none" 
						  data-splitout="none" 
						  data-elementdelay="0.1" 
						  data-endelementdelay="0.1" 
						  data-endspeed="300" 
						  data-captionhidden="on"
						  style=""> <a href="registration.php" class="btn btn-white">REGISTER NOW</a>
					</div>
					</li>
				</ul>
			</div>
		</div>
	</section>
  
  <!-- Content -->
  <div id="content">
  
    <section class="light-gray-bg solution padding-top-50 padding-bottom-50">
      	<div class="container"> 
        	<div class="heading-block text-center margin-bottom-80">
          		<h3>Welcome To RechargeUnlimited</h3>
          		<p>We are a well-known name in the business segment of recharges, reservations and utility payments in India. The website is the comprehensive website catering to the various target groups with its efficient services. </p>
			</div>
        	<ul class="row text-center">
				<li class="col-xs-6 col-md-3"> <img src="images/bus-icon.png" alt="">
            	<h6>BUS TICKETING</h6>
				</li>
				<li class="col-xs-6 col-md-3"> <img src="images/phone-icon.png" alt="">
				<h6>MOBILE RECHARGE</h6>
				</li>
				<li class="col-xs-6 col-md-3"> <img src="images/dish-icon.png" alt="">
				<h6>DTH RECHARGE</h6>
				</li>
				<li class="col-xs-6 col-md-3"> <img src="images/bill-icon.png" alt="">
				<h6>POSTPAID &amp; UITILITY BILLS</h6>
				</li>
        	</ul>
      	</div>
    </section>
    
    <section class="front-page padding-top-50 padding-bottom-50" style="background:#028fc9;">
      	<div class="container">
        	<div class="row">
          		<div class="col-md-6 text-center"> <img class="img-responsive margin-top-10" src="images/operator-1.png" alt=" "> </div>
          		<div class="col-md-6">
					<div class="heading-block text-left margin-bottom-10">
					  <h4 class="text-white">ONE STOP MOBILE BUSINESS APP</h4>
					  <p class="text-white">As a corporate we are committed to develop new strategies and influence business transformations with smart thinking expertise. Our business expertise aims to address the prevailing gaps in various service sectors.</p>
					</div>
					<ul class="list-style text-white">
						<li><p class="text-white"><i class="fa fa-check"></i> All Operator services in single app.</p></li>
						<li><p class="text-white"><i class="fa fa-check"></i> Fast Reliable and Affordable Concept.</p></li>
						<li><p class="text-white"><i class="fa fa-check"></i> Our solution is one stop and economical.</p></li>
						<li><p class="text-white"><i class="fa fa-check"></i> Forget Individual topup get single wallet solution.</p></li>
						<li><p class="text-white"><i class="fa fa-check"></i> One Sim All Recharge Service Platform.</p></li>
						<li><p class="text-white"><i class="fa fa-check"></i> 24x7 sales and business support.</p></li>
					</ul>
					<a href="registration.php" class="btn margin-top-20">REGISTER NOW</a> 
				</div>
        	</div>
      </div>
    </section>
	
    <section class="padding-top-50">
      	<div class="container"> 
        	<div class="heading-block text-center margin-bottom-10">
          		<h4>What Services We Offer </h4>
          		<p>We floated to aggregate, commoditize and distribute the services in most convenient form to the consumers.</p> 
			</div>
        	<div class="text-center"> <img src="images/s-1.png" alt=""> </div>
      	</div>
    </section>
	
    <section class="clients padding-top-50 padding-bottom-50">
      	<div class="container"> 
			<div class="heading-block text-center margin-bottom-30">
		  		<h4 class="text-white">Why Customer <i class="fa fa-heart text-orange"></i> us! </h4>
		 	</div>
        	<div class="row">
                <div class="col-xs-6 col-md-10 padding-top-30">
                  <p class="text-white">"Here's the story of a lovely lady who was bringing up with a small investment. She started working with us and in just a small interval she grew here market with our fast and haselfree recharge services. Today she has a daily turn arround transaction of approx 2500/per day, with a handsome margin of approx 3500 Rs per day." </p>
				  <h6>Kirti Shetty</h6>
                </div>
                <div class="col-md-2"> <img src="images/avatar-2.png" alt=""> </div>
			</div>
        </div>
      </div>
    </section>  
  </div>
  <!-- End Content --> 
<?php include('footer.php');?>