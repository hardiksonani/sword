<?php include('header.php');?>
<!--======= SUB BANNER =========-->
  <section class="sub-banner">
    <div class="container">
      <div class="position-center-center">
        <h2>Bank Details</h2>
        <ul class="breadcrumb">
          <li><a href="http://www.rechargeunlimited.com/">Home</a></li>
          <li>Bank Details</li>
        </ul>
      </div>
    </div>
  </section>
  
  <!-- Content -->
  <div id="content"> 
    
    <!-- Intro -->
    <section class="solution padding-top-30 padding-bottom-100">
      <div class="container">        
        <!-- Tittle -->
        <div class="heading-block text-center margin-bottom-30">
			<h3>Our Bank</h3>
          	<p><img src="images/sbi.png" alt=""></p>
          	<h4></h4>
			<h5></h5>
			<h5> </h5>
		</div>
		
      </div>
    </section>
  </div>
  <!-- End Content --> 
<?php include('footer.php');?>
