<!-- Footer -->
  	<footer>
    	<div class="container">
      		<div class="row">
        		<div class="col-md-6 padding-top-20">           
          		<!-- News Letter -->
          		<div class="news-letter">
            	<h6>News Letter</h6>
            	<form>
              		<input type="email" placeholder="Enter your email..." >
              		<button type="submit"><i class="fa fa-envelope-o"></i></button>
            	</form>
          		</div>
        		</div>
        
        		<!-- Folow Us -->
        		<div class="col-md-6 padding-top-20">
          			<div class="news-letter">
            			<h6>Follow us</h6>
						<ul class="social_icons pull-right margin-left-10 margin-top-10">
						  <li><a href="#."><i class="fa fa-facebook"></i></a></li>
						  <li><a href="#."><i class="fa fa-twitter"></i></a></li>
						  <li><a href="#."><i class="fa fa-google-plus"></i></a></li>
						  <li><a href="#."><i class="fa fa-linkedin"></i></a></li>
						</ul>
          			</div>
        		</div>
      		</div>
    	</div>
    
    	<!-- Footer Info -->
    	<div class="footer-info">
      		<div class="container">
        		<div class="row">
          			<div class="col-md-4"> 
					<img class="margin-bottom-10" src="images/logo-footer.png" alt="" >
            		<ul class="personal-info">
              			<li><i class="fa fa-map-marker"></i> Shreeji Sales, 1, saundary apt., <br> surdhara circe, thaltej,<br> Ahmedabad, Gujarat.</li>
              			<li><i class="fa fa-envelope"></i> info@rechargeunlimited.com</li>
              			<li><i class="fa fa-phone"></i> (91) 079-40052173, 9173887395 </li>
            		</ul>
          			</div>
          
          			<!-- Service provided -->
          			<div class="col-md-4">
            			<h6>Service provided</h6>
						<ul class="links">
						 	<li><a href="http://www.rechargeunlimited.com/">HOME</a></li>
							<li><a href="about.php"> ABOUT </a></li>
							<li><a href="services.php"> SERVICES </a></li>
							<li><a href="bank-details.php">BANK DETAILS</a></li>
							<li><a href="downloads.php"> DOWNLOADS </a></li>
							<li><a href="contact.php"> CONTACT</a></li>
							<li><a href="registration.php"> REGISTRATION</a></li>
							<li><a href="../login"> LOGIN</a></li>
						</ul>
          			</div>
          
          			<!-- Quote -->
          			<div class="col-md-4">
            			<h6>Quick Contact</h6>
            			<div class="quote">
              			<form>
                			<input class="form-control" type="text" placeholder="Name">
                			<input class="form-control" type="text" placeholder="Phone No">
                			<textarea class="form-control" placeholder="Messages"></textarea>
                			<button type="submit" class="btn btn-orange">SEND NOW</button>
              			</form>
            		</div>
          		</div>
        	</div>
      	</div>
    </div>
    
    <!-- Rights -->
    <div class="rights">
      <div class="container">
        <p>Copyright © 2014 rechargeunlimited.com. All Rights Reserved.</p>
      </div>
    </div>
  </footer>
</div>
<!-- JavaScripts -->
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.sticky.js"></script> 
<!-- SLIDER REVOLUTION 4.x SCRIPTS  --> 
<script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script> 
<script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script> 
<script src="js/main.js"></script> 
</body>
</html>