<!doctype html>
<html class="no-js" lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Online Mobile and DTH Recharge Solutions</title>
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
<script src="js/modernizr.js"></script>
<script src="js/jquery.min.js"></script> 
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div id="loader">
  <div class="loader">
    <div class="position-center-center">
      <div id="preloader6"> <span></span> <span></span> <span></span> <span></span>  </div>
    </div>
  </div>
</div>

<!-- Page Wrapper -->
<div id="wrap">
  <div class="top-wrap">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="top-bar">
			  <div class="col-md-3">
				<ul class="social_icons">
				  <li><a href="#."><i class="fa fa-facebook"></i></a></li>
				  <li><a href="#."><i class="fa fa-twitter"></i></a></li>
				  <li><a href="#."><i class="fa fa-google"></i></a></li>
				</ul>
			  </div>
			  <div class="col-md-9">
				<ul class="some-info">
				  <li><i class="fa fa-phone"></i> 079-40052173, 917-388-7395</li>
				  <li><i class="fa fa-envelope"></i> info@rechargeunlimited.com</li>
				  <li><i class="fa fa-weixin"></i> LiveChat</li>
				  <li><i class="fa fa-question-circle"></i> Support</li>
				</ul>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
  </div>
  
  <header class="header coporate-header">
    <div class="sticky">
      <div class="container">
        <div class="logo"> <a href="http://www.rechargeunlimited.com/"><h2 style="color:#FF8000">Recharge Unlimited</h2><!--<img src="images/logo.png" alt="">--></a> </div>
		<div class="main-navigation animated">
			<nav class="navbar" role="navigation">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="fa fa-2x fa-bars"></span>
					</button>
				</div>
				<div class="collapse navbar-collapse" id="navbar-collapse-1">
				  	<ul class="nav navbar-nav">
						<li><a href="http://www.rechargeunlimited.com/ruhome/index.php">HOME</a></li>
						<li><a href="about.php"> ABOUT </a></li>
						<li><a href="services.php"> SERVICES </a></li>
						<li><a href="bank-details.php">BANK DETAILS</a></li>
						<li><a href="downloads.php"> DOWNLOADS </a></li>
						<li><a href="contact.php"> CONTACT</a></li>
						<li><a href="registration.php"> REGISTRATION</a></li>
						<li><a href="../login"> LOGIN</a></li>
				  	</ul>
				</div>
			</nav>
		</div>
	  </div>
    </div>
  </header>
  <!-- End Header --> 
